const treeData = {
  "id": "on795ChccMNur7Kua5Bn60LAOaE7xYRf",
  "name": "DatasetExplorerPage",
  "fileName": "DatasetExplorerPage.tsx",
  "filePath": "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx",
  "importPath": "/",
  "expanded": false,
  "depth": 0,
  "count": 1,
  "thirdParty": false,
  "reactRouter": false,
  "reduxConnect": false,
  "children": [
    {
      "id": "b1xWlMRNlSIL5zE3Chhk0mybYmGzWJ93",
      "name": "DatasetExplorer",
      "fileName": "DatasetExplorer.tsx",
      "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
      "importPath": "../features/DatasetExplorer/DatasetExplorer",
      "expanded": false,
      "depth": 1,
      "thirdParty": false,
      "reactRouter": false,
      "reduxConnect": false,
      "count": 1,
      "props": {
        "dataset": true,
        "tags": true,
        "filters": true,
        "group": true,
        "modelKey": true,
        "groundTruthFlag": true,
        "heatmapFlag": true,
        "predictionsFlag": true,
        "refetchImageIds": true,
        "createTagAndValue": true,
        "assignTags": true,
        "changeHeatmapFlag": true,
        "changeGroundTruthFlag": true,
        "changePredictionsFlag": true,
        "changeGroup": true,
        "removeFilters": true,
        "changeFilters": true
      },
      "children": [
        {
          "id": "S3DvLNGEcp5osiBKZf6mHwBo6wO3aU9T",
          "name": "ScrollContainer",
          "fileName": "ScrollContainer.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/layouts/ScrollContainer.tsx",
          "importPath": "layouts/ScrollContainer.tsx",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {},
          "children": [],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": "Error while processing this file/node"
        },
        {
          "id": "y1ItJaispWc7Wpb9bh7QkvD0bVzeAEvS",
          "name": "PageContainer",
          "fileName": "index.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/layouts/PageContainer/index.tsx",
          "importPath": "layouts/PageContainer",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {},
          "children": [],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "2Ohl26D39MMM2kSEJ4e2PYsjF7y7Ydog",
          "name": "StackLayout",
          "fileName": "index.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/layouts/StackLayout/index.tsx",
          "importPath": "layouts/StackLayout",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {},
          "children": [],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "BeA7EYTClIlHyPgl7Vtb9rxG8JjLtOmO",
          "name": "BigToggle",
          "fileName": "index.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/BigToggle/index.tsx",
          "importPath": "components/BigToggle",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {
            "active": true,
            "buttons": true
          },
          "children": [
            {
              "id": "iiRZGckMUPI4kgQyA8wwmmDPpZ4pyeEV",
              "name": "Typography",
              "fileName": "material",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
              "importPath": "@mui/material",
              "expanded": false,
              "depth": 3,
              "thirdParty": true,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {},
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/components/BigToggle/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            }
          ],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "heLX76eCbZYgzaI8Pz7aDjJA1cG7vfxL",
          "name": "FilterSection",
          "fileName": "FilterSection.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
          "importPath": "features/DatasetExplorer/FilterSection/FilterSection",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {
            "activeFilters": true,
            "availableFilters": true,
            "availableGroups": true,
            "activeGroup": true,
            "removeFilters": true,
            "onFilterChange": true,
            "onGroupChange": true,
            "heatmapFlag": true,
            "groundTruthFlag": true,
            "predictionsFlag": true,
            "changeHeatmapFlag": true,
            "changeGroundTruthFlag": true,
            "changePredictionsFlag": true,
            "taskType": true,
            "onFilterChangeSetValue": true
          },
          "children": [
            {
              "id": "kWBSw2tSNuILTUkFrLEX0a0TD6T6MrsZ",
              "name": "SearchBar",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/SearchBar/index.tsx",
              "importPath": "components/SearchBar",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "buttonMessage": true,
                "onButtonClick": true,
                "onSearchChange": true,
                "value": true,
                "data-cy": true
              },
              "children": [
                {
                  "id": "BXfjCZ1myd6JgSorP3ZzrqYrXRGejoSD",
                  "name": "TextField",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "ref": true,
                    "onKeyDown": true,
                    "error": true,
                    "label": true,
                    "InputProps": true,
                    "position": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/SearchBar/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "9iVy57Df0bwr7JpaZ76ycSsQ76jGvjA4",
                  "name": "InputAdornment",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "position": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/SearchBar/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "YmdO973j1hwp71stdJhwf9RGQI2Gs3pd",
                  "name": "SearchIcon",
                  "fileName": "Search",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/Search",
                  "importPath": "@mui/icons-material/Search",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/SearchBar/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "Yg6Ie27uv9cbTU9oOR4vBhrE5iIpxCLN",
              "name": "Divider",
              "fileName": "material",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
              "importPath": "@mui/material",
              "expanded": false,
              "depth": 3,
              "thirdParty": true,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 2,
              "props": {
                "style": true
              },
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "4s4ptzHSBVYHohpMvmdRSs8dU4uP7T3A",
              "name": "Grid",
              "fileName": "Grid",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Grid",
              "importPath": "@mui/material/Grid",
              "expanded": false,
              "depth": 3,
              "thirdParty": true,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 5,
              "props": {
                "xl": true,
                "lg": true,
                "className": true,
                "spacing": true,
                "alignContent": true,
                "alignItems": true,
                "justifyContent": true,
                "style": true
              },
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "0oUP9xMpCM2bjejHu4pR5PzDHBXtcoeM",
              "name": "FilterCarousel",
              "fileName": "FilterCarousel.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterCarousel/FilterCarousel.tsx",
              "importPath": "features/DatasetExplorer/FilterCarousel/FilterCarousel",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "activeFilters": true,
                "onFilterChange": true
              },
              "children": [
                {
                  "id": "yUwCC8g7eTgSsaPpJ6QllSXHdUMVJbIs",
                  "name": "MultiValuesChip",
                  "fileName": "MultiValuesChip.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                  "importPath": "components/MultiValuesChip/MultiValuesChip",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "name": true,
                    "values": true,
                    "onChipRemove": true
                  },
                  "children": [
                    {
                      "id": "iTvtrnk57G0Nvvc22eaWAXuM3IylgsIj",
                      "name": "TypographyWithMaxLength",
                      "fileName": "index.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                      "importPath": "components/TypographyWithMaxLength",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "lineHeight": true,
                        "maxLength": true,
                        "text": true,
                        "variant": true
                      },
                      "children": [
                        {
                          "id": "CUyCTgL4efljY0ymeCinx48CUWuvy4IM",
                          "name": "Typography",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {},
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterCarousel/FilterCarousel.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "eHd2TnsEaJDxqdwZZ0ukROvhBFeH4MSB",
                          "name": "Tooltip",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "title": true,
                            "placement": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterCarousel/FilterCarousel.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterCarousel/FilterCarousel.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterCarousel/FilterCarousel.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "dM4hIZBXdKIOzOBRQ3eYisGg0olsHRsa",
              "name": "Button",
              "fileName": "material",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
              "importPath": "@mui/material",
              "expanded": false,
              "depth": 3,
              "thirdParty": true,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "className": true,
                "onClick": true,
                "sx": true,
                "data-cy": true
              },
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "fQLV20V1Z1ybLxCPYgj2wYV1T8rKuTbB",
              "name": "MultipleDropdown",
              "fileName": "MultipleDropdown.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/MultipleDropdown.tsx",
              "importPath": "components/MultipleDropdown/MultipleDropdown",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "key": true,
                "text": true,
                "options": true,
                "onFilterClick": true
              },
              "children": [
                {
                  "id": "ntRyw67CQJOZNnADs9yHt2Nr51kv2d6J",
                  "name": "DropdownButton",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/DropdownButton/index.tsx",
                  "importPath": "components/DropdownButton",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "onClick": true,
                    "open": true
                  },
                  "children": [
                    {
                      "id": "6t0e79z41YKxSaTnisT6vA9FdLcs4Qtm",
                      "name": "KeyboardArrowDownIcon",
                      "fileName": "KeyboardArrowDown",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/KeyboardArrowDown",
                      "importPath": "@mui/icons-material/KeyboardArrowDown",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/DropdownButton/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/MultipleDropdown.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/MultipleDropdown.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "KB5tZpSAyIsD7gNwhPp23nIZYFxetaKH",
                  "name": "Menu",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "open": true,
                    "onClose": true,
                    "anchorReference": true,
                    "anchorPosition": true,
                    "data-cy": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/MultipleDropdown.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "PtntDPA50qCVMXdu0SpIRX342xmIv8VA",
                  "name": "MenuItem",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "onClick": true,
                    "key": true,
                    "data-cy": true,
                    "data-id": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/MultipleDropdown.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "3jEr0lrr3vLkf1Ibrj19PNdSj2PdIp8B",
                  "name": "Checkbox",
                  "fileName": "Checkbox",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Checkbox",
                  "importPath": "@mui/material/Checkbox",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "checked": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/MultipleDropdown.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "RGlsxa0tK3w1uKaRlUpX9qD299Ep0KdW",
                  "name": "TypographyWithMaxLength",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                  "importPath": "components/TypographyWithMaxLength",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "maxLength": true,
                    "text": true
                  },
                  "children": [
                    {
                      "id": "96Uj2FxJL2EuSIIUqo8lkTQ5Xwss5O6b",
                      "name": "Typography",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/MultipleDropdown.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "BLDpZJHy1KLFJsRaxFCMEZEkuu6Sh6dy",
                      "name": "Tooltip",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "title": true,
                        "placement": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/MultipleDropdown.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/MultipleDropdown.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "xCQU8zW4weV9jhcYk2Hwt2AivLYZNzjK",
              "name": "FilterDropdown",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
              "importPath": "components/Dropdown",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "key": true,
                "text": true,
                "options": true,
                "selected": true,
                "onFilterClick": true
              },
              "children": [
                {
                  "id": "X0SwDuptXrpFVSOSWqEJGoVpGHctF5At",
                  "name": "DropdownButton",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/DropdownButton/index.tsx",
                  "importPath": "components/DropdownButton",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "onClick": true,
                    "open": true
                  },
                  "children": [
                    {
                      "id": "1eDmHsuRhlPi2VY9CZy0ulrCsjB7b32F",
                      "name": "KeyboardArrowDownIcon",
                      "fileName": "KeyboardArrowDown",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/KeyboardArrowDown",
                      "importPath": "@mui/icons-material/KeyboardArrowDown",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/DropdownButton/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "g14FEBiAuRaKJE53fOrIYgbrulBBO3eD",
                  "name": "DropDown",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                  "importPath": "components/DropdownMenu",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "items": true,
                    "handleClose": true,
                    "anchorEl": true
                  },
                  "children": [
                    {
                      "id": "B5TpDUZV76p8vy6PRmsXY0moEV6aAQFq",
                      "name": "Menu",
                      "fileName": "Menu",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Menu",
                      "importPath": "@mui/material/Menu",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "id": true,
                        "anchorEl": true,
                        "open": true,
                        "onClose": true,
                        "anchorOrigin": true,
                        "sx": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "YL6il33A0oDUyiCZf6p8HesWtCu2SNPd",
                      "name": "MenuItem",
                      "fileName": "MenuItem",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/MenuItem",
                      "importPath": "@mui/material/MenuItem",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "data-cy": true,
                        "data-id": true,
                        "key": true,
                        "style": true,
                        "onClick": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "6aPgosJySQLoaK0T1afhfcM02csNoyge",
                      "name": "Checkbox",
                      "fileName": "Checkbox",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Checkbox",
                      "importPath": "@mui/material/Checkbox",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "checked": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "VLyascYzfUsUC3RsNgeisBLEFD0wEvbd",
              "name": "RangeDropdown",
              "fileName": "RangeDropdown.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/RangeDropdown/RangeDropdown.tsx",
              "importPath": "components/MultipleDropdown/RangeDropdown/RangeDropdown",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "text": true,
                "activeFilters": true,
                "options": true,
                "onFilterChange": true
              },
              "children": [
                {
                  "id": "w9B4IhL9aCyhIk8xIUGxfLVP7alvnLV3",
                  "name": "KeyboardArrowDownIcon",
                  "fileName": "KeyboardArrowDown",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/KeyboardArrowDown",
                  "importPath": "@mui/icons-material/KeyboardArrowDown",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/RangeDropdown/RangeDropdown.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "iL330eg7u5w3wMbCNSaG5OFr2gAOgT9m",
                  "name": "Menu",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "id": true,
                    "MenuListProps": true,
                    "anchorEl": true,
                    "open": true,
                    "onClose": true,
                    "TransitionComponent": true,
                    "anchorOrigin": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/RangeDropdown/RangeDropdown.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "foFIzsovBJ2NJ3C5rIFLDS1TZKqREVf1",
                  "name": "RangeMenuItem",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/RangeMenuItem/index.tsx",
                  "importPath": "components/RangeMenuItem",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "key": true,
                    "values": true,
                    "title": true,
                    "onFilterChange": true
                  },
                  "children": [
                    {
                      "id": "jD5yNw5ZwYb7KVbhvylJKDtUB76njWXG",
                      "name": "MenuItem",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "style": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/RangeMenuItem/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/RangeDropdown/RangeDropdown.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "ptgvsejft67A3InKCbxGbUm66e4HT2Ja",
                      "name": "Box",
                      "fileName": "Box",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Box",
                      "importPath": "@mui/material/Box",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "width": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/RangeMenuItem/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/RangeDropdown/RangeDropdown.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "iqvjq8rJIZfYlKbO9JUtoQxq6MlubCVF",
                      "name": "Typography",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "variant": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/RangeMenuItem/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/RangeDropdown/RangeDropdown.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "5fiFb68Ke1fUd4RCR1wLyR4SsPgs2lkl",
                      "name": "UnitIntervalSlider",
                      "fileName": "UnitIntervalSlider.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/UnitIntervalSlider/UnitIntervalSlider.tsx",
                      "importPath": "components/UnitIntervalSlider/UnitIntervalSlider",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "values": true,
                        "onSliderChange": true
                      },
                      "children": [
                        {
                          "id": "puIaid6NVZc5BpxC763TzueaSnYRdCoh",
                          "name": "Slider",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "size": true,
                            "min": true,
                            "max": true,
                            "scale": true,
                            "step": true,
                            "value": true,
                            "onChange": true,
                            "valueLabelDisplay": true,
                            "marks": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/UnitIntervalSlider/UnitIntervalSlider.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/RangeMenuItem/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/RangeDropdown/RangeDropdown.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/RangeMenuItem/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/RangeDropdown/RangeDropdown.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/MultipleDropdown/RangeDropdown/RangeDropdown.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "lFo2DzEYg3ukRmT14jg8KSEfW3axryw2",
              "name": "ToggleSwitch",
              "fileName": "SwitchButton",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/SwitchButton/SwitchButton",
              "importPath": "components/SwitchButton/SwitchButton",
              "expanded": false,
              "depth": 3,
              "thirdParty": true,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 3,
              "props": {
                "text": true,
                "checked": true,
                "onChange": true
              },
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "y3zPOAT505YVqPeFI6osf908dIyupIkQ",
              "name": "GroupByDropDown",
              "fileName": "GroupByDropDown.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/GroupByDropDown/GroupByDropDown.tsx",
              "importPath": "features/DatasetExplorer/GroupByDropDown/GroupByDropDown",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "activeGroup": true,
                "onGroupChange": true,
                "options": true
              },
              "children": [
                {
                  "id": "OltGasCHtO0dlfijo1In0UYYoRLAhADV",
                  "name": "Button",
                  "fileName": "Button",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Button",
                  "importPath": "@mui/material/Button",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "id": true,
                    "aria-controls": true,
                    "aria-haspopup": true,
                    "className": true,
                    "sx": true,
                    "aria-expanded": true,
                    "onClick": true,
                    "startIcon": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/GroupByDropDown/GroupByDropDown.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "Mo2nHFXpS2D5Eec2gAmNqKKkNjqURe9l",
                  "name": "ViewCompactIcon",
                  "fileName": "ViewCompact",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/ViewCompact",
                  "importPath": "@mui/icons-material/ViewCompact",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "sx": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/GroupByDropDown/GroupByDropDown.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "vrjGjSVXjKnuf8Afdk6DnRni6GwocWrp",
                  "name": "DropDown",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                  "importPath": "components/DropdownMenu",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "items": true,
                    "handleClose": true,
                    "anchorEl": true
                  },
                  "children": [
                    {
                      "id": "cNrf9TNMukLQJhgdB6Xd7GaX5Oy7e9bi",
                      "name": "Menu",
                      "fileName": "Menu",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Menu",
                      "importPath": "@mui/material/Menu",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "id": true,
                        "anchorEl": true,
                        "open": true,
                        "onClose": true,
                        "anchorOrigin": true,
                        "sx": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/GroupByDropDown/GroupByDropDown.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "49elS0WgrC8ncnXLL77ta9E3uqe6aKDU",
                      "name": "MenuItem",
                      "fileName": "MenuItem",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/MenuItem",
                      "importPath": "@mui/material/MenuItem",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "data-cy": true,
                        "data-id": true,
                        "key": true,
                        "style": true,
                        "onClick": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/GroupByDropDown/GroupByDropDown.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "JXqpu6GiH4bt7P3wAp7LPfVpIgBY7Tqu",
                      "name": "Checkbox",
                      "fileName": "Checkbox",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Checkbox",
                      "importPath": "@mui/material/Checkbox",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "checked": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/GroupByDropDown/GroupByDropDown.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/GroupByDropDown/GroupByDropDown.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FilterSection/FilterSection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            }
          ],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "spou07homZSCuEXG0NhXpSFlM36KLSUq",
          "name": "FillAvailableContainer",
          "fileName": "index.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/layouts/FillAvailableContainer/index.tsx",
          "importPath": "layouts/FillAvailableContainer",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {},
          "children": [],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "avesg6AsmNrDg6kzFDpwdBujC9aztcFa",
          "name": "TabPanel",
          "fileName": "index.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TabsContainer/TabPanel/index.tsx",
          "importPath": "./TabsContainer/TabPanel",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 2,
          "props": {
            "value": true,
            "index": true
          },
          "children": [
            {
              "id": "wFUDxcyzpvcHNXWw3PaCewaNdp0cZXmV",
              "name": "Box",
              "fileName": "material",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
              "importPath": "@mui/material",
              "expanded": false,
              "depth": 3,
              "thirdParty": true,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "sx": true
              },
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TabsContainer/TabPanel/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            }
          ],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "pj4Y2WaHzpo9om0MuW8FoL234rDGMFML",
          "name": "SectionContainer",
          "fileName": "index.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/layouts/SectionContainer/index.tsx",
          "importPath": "layouts/SectionContainer",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {},
          "children": [],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "LhQlZF67oX1oNKLKK7ConlSQj4j2NTJw",
          "name": "SummarySection",
          "fileName": "SummarySection.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/SummarySection/SummarySection.tsx",
          "importPath": "features/DatasetExplorer/SummarySection/SummarySection",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {},
          "children": [
            {
              "id": "IlCWG2JChHXDq3jYQd4wlfL5CINPORTd",
              "name": "Stack",
              "fileName": "material",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
              "importPath": "@mui/material",
              "expanded": false,
              "depth": 3,
              "thirdParty": true,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "mt": true,
                "direction": true,
                "alignItems": true,
                "justifyContent": true
              },
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/SummarySection/SummarySection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "HwFLc0wqZ3z4AvFGppzrsJljPV1TgRi8",
              "name": "Typography",
              "fileName": "material",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
              "importPath": "@mui/material",
              "expanded": false,
              "depth": 3,
              "thirdParty": true,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "fontWeight": true
              },
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/SummarySection/SummarySection.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            }
          ],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "yhFgtmeBTcC9PQ2EryysroP8rZzBkWDH",
          "name": "OverviewImageGroups",
          "fileName": "index.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
          "importPath": "features/DatasetExplorer/OverviewImageGroups",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {
            "dataset": true,
            "onCreateNewTagAndValue": true,
            "assignTags": true,
            "filters": true,
            "tags": true,
            "modelKey": true,
            "groupBy": true,
            "refetchImageIds": true
          },
          "children": [
            {
              "id": "bzP2CnnL0dNDR8TDw8oHpiKRBmSRwR5q",
              "name": "LoaderWrapper",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/LoaderWrapper/index.tsx",
              "importPath": "components/LoaderWrapper",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "isLoaded": true,
                "loaderSize": true,
                "messageEmpty": true
              },
              "children": [
                {
                  "id": "UZkf7s9fsDjxMbGgsEG42flhxaa7h4IO",
                  "name": "CircularProgress",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "size": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/LoaderWrapper/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "Srieesd1z6QFANVtXOEs24eQDWC73tmx",
                  "name": "Typography",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/LoaderWrapper/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "tZZebSAmkW121uvcImBVMhSPD6JxNdoc",
              "name": "FolderOffIcon",
              "fileName": "FolderOff",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/FolderOff",
              "importPath": "@mui/icons-material/FolderOff",
              "expanded": false,
              "depth": 3,
              "thirdParty": true,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "fontSize": true
              },
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "cEOmgge8ycXXy2WQaJlMHaJmqIL4aaml",
              "name": "Typography",
              "fileName": "material",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
              "importPath": "@mui/material",
              "expanded": false,
              "depth": 3,
              "thirdParty": true,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 2,
              "props": {},
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "PX9yuoCoyzGmNSaxFnAyAVWrpZQLF5I6",
              "name": "TopMenu",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
              "importPath": "../ImagesTopMenu",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "filters": true,
                "groupBy": true,
                "onExportClicked": true,
                "onVerifyClicked": true,
                "onTagClicked": true,
                "selectEnabled": true,
                "cancelClicked": true,
                "selectClicked": true,
                "toggleFilters": true,
                "getImageIdFromEmbeddingView": true
              },
              "children": [
                {
                  "id": "1riyw9IJIQpgu16ZFHStYjGEUNDbZlhI",
                  "name": "MenuItem",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "key": true,
                    "style": true,
                    "onClick": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "73K8qaFFngf8PPks24QINPeZubvO2SsD",
                  "name": "CheckIcon",
                  "fileName": "Check",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/Check",
                  "importPath": "@mui/icons-material/Check",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "sx": true,
                    "color": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "DvYks1qn62Hm4fv576NIGHw6Ksf0a9Zr",
                  "name": "Typography",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "ml": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "BEiDWFHH7PfYZyKFvs6uCHGBc5WQZiba",
                  "name": "Stack",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "mt": true,
                    "direction": true,
                    "alignItems": true,
                    "justifyContent": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "NiVxljwTnoxJwOELBIIrJsxt6xLVwxsN",
                  "name": "Button",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 3,
                  "props": {
                    "data-cy": true,
                    "onClick": true,
                    "color": true,
                    "id": true,
                    "aria-controls": true,
                    "aria-haspopup": true,
                    "sx": true,
                    "aria-expanded": true,
                    "variant": true,
                    "endIcon": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "Ks2YjrbjAR52MH7UlzNmRKYaLWKwS2xf",
                  "name": "TripleDotsMenu",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/TripleDotsMenu/index.tsx",
                  "importPath": "./TripleDotsMenu",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "onTagClicked": true,
                    "onExportClicked": true,
                    "onVerifyClicked": true,
                    "enabled": true
                  },
                  "children": [
                    {
                      "id": "rSV9ysqwfrmofu91klu1YQr54ylfzGtL",
                      "name": "IconButton",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "data-cy": true,
                        "disabled": true,
                        "onClick": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/TripleDotsMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "kCznPiMCjNo6dG1wnJNf87Qf7gy1OkEL",
                      "name": "MoreHoriz",
                      "fileName": "icons-material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material",
                      "importPath": "@mui/icons-material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/TripleDotsMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "7L1zMPcuGOB8aIE2iFe0x0nfRUeskPcj",
                      "name": "Menu",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "id": true,
                        "MenuListProps": true,
                        "anchorEl": true,
                        "open": true,
                        "onClose": true,
                        "sx": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/TripleDotsMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "msCS4l2pioaJjeAIrK0LcjxVJ2UqN36o",
                      "name": "MenuItem",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 3,
                      "props": {
                        "onClick": true,
                        "data-cy": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/TripleDotsMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "oCzSCn6dhiBMq0L7IXZRlFwa8NmEUVYy",
                      "name": "Typography",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 3,
                      "props": {
                        "mr": true,
                        "color": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/TripleDotsMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "GUDUdyzsbt22E9dcsfTlbGTpSFpvtpQa",
                      "name": "LocalOfferIcon",
                      "fileName": "LocalOffer",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/LocalOffer",
                      "importPath": "@mui/icons-material/LocalOffer",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "fontSize": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/TripleDotsMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "NmxWnRcfeEvBAuxfBXDIDbUJLpfQC5fS",
                      "name": "DownloadIcon",
                      "fileName": "Download",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/Download",
                      "importPath": "@mui/icons-material/Download",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "fontSize": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/TripleDotsMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "O1vlYGp7SQVC2lHx0dUVokEaeI9MWV2f",
                      "name": "HideUnlessFeatureEnabled",
                      "fileName": "HideUnlessFeatureEnabled.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HideUnlessFeatureEnabled/HideUnlessFeatureEnabled.tsx",
                      "importPath": "components/HideUnlessFeatureEnabled/HideUnlessFeatureEnabled",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "flag": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/TripleDotsMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "w8cnkAYpef4lCjPqVLNpfaSTPbW4AO6m",
                      "name": "CheckIcon",
                      "fileName": "Check",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/Check",
                      "importPath": "@mui/icons-material/Check",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "fontSize": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/TripleDotsMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "dOi9Os8kGM5T9advCuzvIfLeYjfdXO34",
                  "name": "CustomDraggable",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                  "importPath": "features/DatasetExplorer/ChartCustomDraggable",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "getImageIdFromEmbeddingView": true,
                    "filters": true,
                    "groupBy": true,
                    "toggleFilters": true
                  },
                  "children": [
                    {
                      "id": "SD12ndc2LtRhdeifgdmRalwXpSIVx3j9",
                      "name": "Button",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "data-cy": true,
                        "onClick": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "8dFVqdHJWJPA0wgxWooOxNBBso7dagHz",
                      "name": "ResizableWindow",
                      "fileName": "index.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                      "importPath": "components/ResizableWindow",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "title": true,
                        "fullView": true,
                        "onFullView": true,
                        "onMinimize": true,
                        "onClose": true,
                        "onResize": true
                      },
                      "children": [
                        {
                          "id": "FVBPJse3FCCHTzcepdl8Fm30rl3QO6Sa",
                          "name": "Draggable",
                          "fileName": "react-draggable",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/react-draggable",
                          "importPath": "react-draggable",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "handle": true,
                            "ref": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "8Y1MBLuejy3VdJKfeBLPHjD3l7rTNyOK",
                          "name": "Stack",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 2,
                          "props": {
                            "id": true,
                            "direction": true,
                            "justifyContent": true,
                            "alignItems": true,
                            "p": true,
                            "gap": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "88aLyujirlGChYCwNfeVqncY6c36RTa8",
                          "name": "Typography",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "paddingX": true,
                            "variant": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "EHzj80hjxYzzw6moyJoN3YriYIdV8Ow5",
                          "name": "Button",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {},
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "Rx1LfSGWlPqUM8cA2FWlUWm47Bn4jQfM",
                          "name": "CloseFullscreenIcon",
                          "fileName": "CloseFullscreen",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/CloseFullscreen",
                          "importPath": "@mui/icons-material/CloseFullscreen",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "onClick": true,
                            "sx": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "inCvEESJj3RmuxSUnWclThntHpZZB0Pc",
                          "name": "OpenInFullIcon",
                          "fileName": "OpenInFull",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/OpenInFull",
                          "importPath": "@mui/icons-material/OpenInFull",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "onClick": true,
                            "sx": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "HVpRTuh0oDtxkLiSkjx1wIpJlXbwBHal",
                          "name": "CloseIcon",
                          "fileName": "Close",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/Close",
                          "importPath": "@mui/icons-material/Close",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "onClick": true,
                            "sx": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "DfvjRozYtH1CcoC0uUd5B0MwSwUVpkSH",
                      "name": "Stepper",
                      "fileName": "index.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/Stepper/index.tsx",
                      "importPath": "components/Stepper",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "onStepChange": true
                      },
                      "children": [
                        {
                          "id": "pCjtkoONIFcT38rMnKUQxLSeudH0qchW",
                          "name": "MobileStepper",
                          "fileName": "MobileStepper",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/MobileStepper",
                          "importPath": "@mui/material/MobileStepper",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "steps": true,
                            "position": true,
                            "variant": true,
                            "activeStep": true,
                            "sx": true,
                            "nextButton": true,
                            "size": true,
                            "onClick": true,
                            "disabled": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/Stepper/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "5nyuyyP5HkfaLNoqVhZobLUZKPa0w7vG",
                          "name": "Button",
                          "fileName": "Button",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Button",
                          "importPath": "@mui/material/Button",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 2,
                          "props": {
                            "size": true,
                            "onClick": true,
                            "disabled": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/Stepper/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "WK37Zm6QSulnyyLTyMUoohmg9sczoePY",
                          "name": "KeyboardArrowRight",
                          "fileName": "KeyboardArrowRight",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/KeyboardArrowRight",
                          "importPath": "@mui/icons-material/KeyboardArrowRight",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {},
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/Stepper/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "h6kqLSQeGXg2culCM20wRoa0ymH9R3Cv",
                          "name": "KeyboardArrowLeft",
                          "fileName": "KeyboardArrowLeft",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/KeyboardArrowLeft",
                          "importPath": "@mui/icons-material/KeyboardArrowLeft",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {},
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/Stepper/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "mnIfk1jWePDi7gu2O5SPs0j27USiThfk",
                      "name": "ConfusionMatrix",
                      "fileName": "ConfusionMatrix.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/ConfusionMatrix.tsx",
                      "importPath": "components/HighCharts/ConfusionMatrix",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "ref": true,
                        "data": true,
                        "xAxisCategories": true,
                        "yAxisCategories": true,
                        "xAxisFilters": true,
                        "yAxisFilters": true,
                        "title": true,
                        "onPointClicked": true
                      },
                      "children": [
                        {
                          "id": "g5S32XqrzYZna66PUFfTeWJg1ITMdfqG",
                          "name": "HighchartsReact",
                          "fileName": "highcharts-react-official",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/highcharts-react-official",
                          "importPath": "highcharts-react-official",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "ref": true,
                            "highcharts": true,
                            "containerProps": true,
                            "options": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/ConfusionMatrix.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "qZfXVNl5l2OV5J7YEeZd1SXIeiMuzkeP",
                      "name": "CircularProgress",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "POsrumQZINdu0wF2UcVQfjoW8cYVuM8m",
                      "name": "EmbeddingView",
                      "fileName": "index.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                      "importPath": "components/HighCharts/EmbeddingViewer",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "ref": true,
                        "datasetName": true,
                        "viewerData": true,
                        "embeddingType": true,
                        "onEmbeddingTypeChange": true,
                        "getImageIdFromEmbeddingView": true,
                        "embeddingSource": true,
                        "onEmbeddingSourceChange": true,
                        "colorByOptions": true,
                        "colorBy": true,
                        "onColorByChange": true,
                        "loading": true
                      },
                      "children": [
                        {
                          "id": "a1PmKNnS5BQcxdOGsHIfrOfnc69QFgsE",
                          "name": "Box",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 6,
                          "props": {
                            "display": true,
                            "flexDirection": true,
                            "alignItems": true,
                            "gap": true,
                            "justifyContent": true,
                            "height": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "xJR44uOVrbBhQOPBIU6pd0rAEEKVwjHj",
                          "name": "ItemGroup",
                          "fileName": "index.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/ItemGroup/index.tsx",
                          "importPath": "components/ItemGroup",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 2,
                          "props": {
                            "title": true
                          },
                          "children": [
                            {
                              "id": "tr0CJuAFbC8lImfHdDLjKtcWmYagbIjG",
                              "name": "Box",
                              "fileName": "material",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                              "importPath": "@mui/material",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "position": true,
                                "color": true,
                                "top": true,
                                "left": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/ItemGroup/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "CvTgqQFj9srv9SrD03FviSil0L9GOg8N",
                              "name": "Typography",
                              "fileName": "material",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                              "importPath": "@mui/material",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "variant": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/ItemGroup/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "41gCZ9KFcLHoxLFQhqVoaxhZ6TPem0rX",
                              "name": "React",
                              "fileName": "react",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/react",
                              "importPath": "react",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "key": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/ItemGroup/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "OwQ138pDTH5ctTeZhW9VrNl581p6SGrS",
                              "name": "Divider",
                              "fileName": "material",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                              "importPath": "@mui/material",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "variant": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/ItemGroup/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "eUlQkxlRwRfVyk33VSPjxZWygiIi43WI",
                          "name": "Typography",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 6,
                          "props": {},
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "x3nTJm4VnigBbhOJxrukZXgSz5J22Gy8",
                          "name": "ToggleButtonGroup",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 4,
                          "props": {
                            "color": true,
                            "value": true,
                            "onChange": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "FJQ4yth94cFd59anDOH1BNvtZY8UHJZX",
                          "name": "ToggleButton",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 7,
                          "props": {
                            "key": true,
                            "value": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "blLNdRwLwVFO8cc1txql1bC9Tx6l9Yvq",
                          "name": "Dropdown",
                          "fileName": "index.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                          "importPath": "components/Dropdown",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 2,
                          "props": {
                            "text": true,
                            "options": true,
                            "selected": true,
                            "onFilterClick": true
                          },
                          "children": [
                            {
                              "id": "YQlh4KZIXrbxeuh4p2wIb6sJ65D7jMHx",
                              "name": "DropdownButton",
                              "fileName": "index.tsx",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/DropdownButton/index.tsx",
                              "importPath": "components/DropdownButton",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": false,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "onClick": true,
                                "open": true
                              },
                              "children": [
                                {
                                  "id": "l35eUfpn19OSSiBi9Pm4FGixAy1cceBm",
                                  "name": "KeyboardArrowDownIcon",
                                  "fileName": "KeyboardArrowDown",
                                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/KeyboardArrowDown",
                                  "importPath": "@mui/icons-material/KeyboardArrowDown",
                                  "expanded": false,
                                  "depth": 8,
                                  "thirdParty": true,
                                  "reactRouter": false,
                                  "reduxConnect": false,
                                  "count": 1,
                                  "props": {},
                                  "children": [],
                                  "parentList": [
                                    "/Users/aue/Documents/dashboard/frontend/src/components/DropdownButton/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                                  ],
                                  "error": ""
                                }
                              ],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "8dNy6FmAICqFLJt5IMuwJ14qdS2H2czj",
                              "name": "DropDown",
                              "fileName": "index.tsx",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                              "importPath": "components/DropdownMenu",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": false,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "items": true,
                                "handleClose": true,
                                "anchorEl": true
                              },
                              "children": [
                                {
                                  "id": "CSsymRKpZ36EuvvEGrU5O882wF1u73xA",
                                  "name": "Menu",
                                  "fileName": "Menu",
                                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Menu",
                                  "importPath": "@mui/material/Menu",
                                  "expanded": false,
                                  "depth": 8,
                                  "thirdParty": true,
                                  "reactRouter": false,
                                  "reduxConnect": false,
                                  "count": 1,
                                  "props": {
                                    "id": true,
                                    "anchorEl": true,
                                    "open": true,
                                    "onClose": true,
                                    "anchorOrigin": true,
                                    "sx": true
                                  },
                                  "children": [],
                                  "parentList": [
                                    "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                                  ],
                                  "error": ""
                                },
                                {
                                  "id": "Nqtmwmq3qlC6qkUtWS8jluTKVpTceGZ4",
                                  "name": "MenuItem",
                                  "fileName": "MenuItem",
                                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/MenuItem",
                                  "importPath": "@mui/material/MenuItem",
                                  "expanded": false,
                                  "depth": 8,
                                  "thirdParty": true,
                                  "reactRouter": false,
                                  "reduxConnect": false,
                                  "count": 1,
                                  "props": {
                                    "data-cy": true,
                                    "data-id": true,
                                    "key": true,
                                    "style": true,
                                    "onClick": true
                                  },
                                  "children": [],
                                  "parentList": [
                                    "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                                  ],
                                  "error": ""
                                },
                                {
                                  "id": "GhVXND3TH3yiEtuIOGp5nByGDegri5u6",
                                  "name": "Checkbox",
                                  "fileName": "Checkbox",
                                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Checkbox",
                                  "importPath": "@mui/material/Checkbox",
                                  "expanded": false,
                                  "depth": 8,
                                  "thirdParty": true,
                                  "reactRouter": false,
                                  "reduxConnect": false,
                                  "count": 1,
                                  "props": {
                                    "checked": true
                                  },
                                  "children": [],
                                  "parentList": [
                                    "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                                  ],
                                  "error": ""
                                }
                              ],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "Hle4gAM6frpx0oac5p75KqRoyz85IA7T",
                          "name": "LoadingBarWithMessage",
                          "fileName": "LoadingBar",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/LoadingBar",
                          "importPath": "components/HighCharts/EmbeddingViewer/LoadingBar",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "message": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "xOQMwLYioDLfEU2YevtJ8hVukLleH6bW",
                          "name": "ScatterPlot",
                          "fileName": "ScatterPlot.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/ScatterPlot.tsx",
                          "importPath": "components/HighCharts/ScatterPlot",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "ref": true,
                            "datasetName": true,
                            "title": true,
                            "xAxisTitle": true,
                            "yAxisTitle": true,
                            "data": true,
                            "isLegendVisible": true,
                            "isImageAsPoint": true,
                            "getImageIdFromEmbeddingView": true
                          },
                          "children": [
                            {
                              "id": "uX7VSz52ds9xaqP8A371VdLjGpHM00Co",
                              "name": "HighchartsReact",
                              "fileName": "highcharts-react-official",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/highcharts-react-official",
                              "importPath": "highcharts-react-official",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "ref": true,
                                "highcharts": true,
                                "options": true,
                                "containerProps": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/ScatterPlot.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "n6PB5l0M3yQtpih7VllIyM41ou9Wz8ML",
                  "name": "Box",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "hHAX9Qw3NQW8NL7Vq9C2fzGocsgASt52",
                  "name": "ArrowDropDownIcon",
                  "fileName": "ArrowDropDown",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/ArrowDropDown",
                  "importPath": "@mui/icons-material/ArrowDropDown",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "DYc2AVM5vWVbPiJBxhrZxfgIyJ4bQ961",
                  "name": "Menu",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "id": true,
                    "MenuListProps": true,
                    "anchorEl": true,
                    "open": true,
                    "onClose": true,
                    "TransitionComponent": true,
                    "anchorOrigin": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "FgIWAjqW6n815uIoFEjEuyDIMzSL1yIg",
                  "name": "IconButton",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "onClick": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "3cU3F1NErwftnOSyzoETOSjEhzp0Aj9t",
                  "name": "LocalOffer",
                  "fileName": "icons-material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material",
                  "importPath": "@mui/icons-material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImagesTopMenu/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "q5HXhtmMxoAZEu5weJhwiU5ZqPYtgJ8e",
              "name": "ImageGroups",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
              "importPath": "features/DatasetExplorer/ImageGroups",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {},
              "children": [
                {
                  "id": "XpE466jBzlU7qDOVN5wRzVguOxSIXP2J",
                  "name": "Accordion",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                  "importPath": "components/Accordion",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "title": true,
                    "startExpanded": true,
                    "rightActionBar": true,
                    "visible": true,
                    "allSelected": true,
                    "selectAll": true,
                    "deselectAll": true
                  },
                  "children": [
                    {
                      "id": "H8y0KehGxQdKXvJQIMAcdNCdxmmKnvdy",
                      "name": "Accordion",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "id": true,
                        "data-cy": true,
                        "sx": true,
                        "expanded": true,
                        "ref": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "FSwxjAIsuAmyGACpoW14eNj8u80N6rxY",
                      "name": "AccordionSummary",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "onClick": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "NyFslF2v2VPLtvjSVOjuUMd4hmcXa1nZ",
                      "name": "Box",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 3,
                      "props": {
                        "display": true,
                        "justifyContent": true,
                        "width": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "S0Fo98XtVMtFet02HCZlThN28EnTFF5o",
                      "name": "Typography",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 2,
                      "props": {
                        "mr": true,
                        "color": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "eNu6elNqaCvnTQ2kUSZAHU4SgWacDnDD",
                      "name": "ArrowUpwardIcon",
                      "fileName": "ArrowUpward",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/ArrowUpward",
                      "importPath": "@mui/icons-material/ArrowUpward",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "p3blrHpAKWseRYbNvZBnmhI5BqDGnld6",
                      "name": "ArrowDownwardIcon",
                      "fileName": "ArrowDownward",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/ArrowDownward",
                      "importPath": "@mui/icons-material/ArrowDownward",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "MQtd5uW0IS3eayOZKpc0nULrbbLj7Hve",
                      "name": "AccordionDetails",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "sx": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "tipJadORaNHhPZQxfKTb91ES3l9PF7Gv",
                  "name": "ImageGroupAccordionActionBar",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/ImageGroupAccordionActionBar/index.tsx",
                  "importPath": "components/ImageGroupAccordionActionBar",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "visible": true,
                    "allSelected": true,
                    "selectAll": true,
                    "deselectAll": true
                  },
                  "children": [
                    {
                      "id": "53fjjWxXCqi6AG1H7qxnuEqRuVQbtdW0",
                      "name": "Button",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "onClick": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/ImageGroupAccordionActionBar/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "n5ZSvt7yWKklqNTqnw3FNCynhUXdhN6O",
                  "name": "ImageList",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/ImageList/index.tsx",
                  "importPath": "components/ImageList",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "id": true,
                    "dataLength": true,
                    "fetchNextPage": true,
                    "hasMore": true
                  },
                  "children": [
                    {
                      "id": "4d0ZnRr62Y6B9CDGCnOW0KZLfe1ZEviq",
                      "name": "InfiniteScroll",
                      "fileName": "react-infinite-scroll-component",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/react-infinite-scroll-component",
                      "importPath": "react-infinite-scroll-component",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "dataLength": true,
                        "next": true,
                        "scrollThreshold": true,
                        "scrollableTarget": true,
                        "hasMore": true,
                        "loader": true,
                        "style": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/ImageList/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "N45s5pyccMk91T4j8S1LZUxgfaJdSsqb",
                      "name": "CircularProgress",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/ImageList/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "C5V7xACWmBY7xCHvSLryksDhv5HMzsD5",
                  "name": "ImageCard",
                  "fileName": "ImageCard.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImgScrollerView/ImageCard/ImageCard.tsx",
                  "importPath": "../ImageView/ImgScrollerView/ImageCard/ImageCard",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "key": true,
                    "image": true,
                    "selected": true,
                    "groundTruthBB": true,
                    "heatmapMode": true,
                    "predictionBB": true,
                    "showTags": true,
                    "handleImageClick": true
                  },
                  "children": [
                    {
                      "id": "rhq8T30n6anuwPrwygDd6uJW41FaIesj",
                      "name": "CardMedia",
                      "fileName": "CardMedia",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/CardMedia",
                      "importPath": "@mui/material/CardMedia",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "style": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImgScrollerView/ImageCard/ImageCard.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "9LwmBwq09pkfyA11K9cSFTRKQmzuBrDp",
                      "name": "LoadImageWithMetaInfo",
                      "fileName": "LoadImageWithMetaInfo.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/LoadImageWithMetaInfo/LoadImageWithMetaInfo.tsx",
                      "importPath": "../../LoadImageWithMetaInfo/LoadImageWithMetaInfo",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "groundTruthBB": true,
                        "heatmapMode": true,
                        "predictionBB": true,
                        "image": true
                      },
                      "children": [
                        {
                          "id": "68dPDJzbTgfTiygRCwquyYgjp3nDa1ea",
                          "name": "ImageWithBoxImmutable",
                          "fileName": "ImageWithBoxImmutable.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImageWithBoxImmutable/ImageWithBoxImmutable.tsx",
                          "importPath": "../ImageWithBoxImmutable/ImageWithBoxImmutable",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "groundTruthBB": true,
                            "predictionBB": true,
                            "image": true,
                            "predictionCoordinates": true,
                            "groundTruthCoordinates": true
                          },
                          "children": [
                            {
                              "id": "9nIWrBihaBqFxTpBpkh1x5yOfpwugYl2",
                              "name": "BoundingBoxSvgComponent",
                              "fileName": "index.tsx",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/BoundingBoxCanvas/BoundingBoxSvgComponent/index.tsx",
                              "importPath": "features/DatasetExplorer/BoundingBoxCanvas/BoundingBoxSvgComponent",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": false,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "key": true,
                                "x": true,
                                "y": true,
                                "width": true,
                                "height": true,
                                "strokeWidth": true,
                                "strokeDash": true,
                                "color": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImageWithBoxImmutable/ImageWithBoxImmutable.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/LoadImageWithMetaInfo/LoadImageWithMetaInfo.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImgScrollerView/ImageCard/ImageCard.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/LoadImageWithMetaInfo/LoadImageWithMetaInfo.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImgScrollerView/ImageCard/ImageCard.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImgScrollerView/ImageCard/ImageCard.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "53L6X6lMIHOTmEMF7iMJXLlkX0HMkeGt",
                      "name": "TagList",
                      "fileName": "index.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagList/index.tsx",
                      "importPath": "features/DatasetExplorer/TagList",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "maxValuesLength": true,
                        "tags": true
                      },
                      "children": [
                        {
                          "id": "o5MQggRP23HxwIRdom5pSicnsPYn7awu",
                          "name": "MultiValuesChip",
                          "fileName": "MultiValuesChip.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                          "importPath": "components/MultiValuesChip/MultiValuesChip",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "nameLength": true,
                            "valuesLength": true,
                            "small": true,
                            "key": true,
                            "name": true,
                            "values": true,
                            "onChipRemove": true,
                            "chipColor": true
                          },
                          "children": [
                            {
                              "id": "bImOBJ8Aw3s7z4Zm3GxyT62YTyrKaDZJ",
                              "name": "TypographyWithMaxLength",
                              "fileName": "index.tsx",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                              "importPath": "components/TypographyWithMaxLength",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": false,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "lineHeight": true,
                                "maxLength": true,
                                "text": true,
                                "variant": true
                              },
                              "children": [
                                {
                                  "id": "GLJtPEjFuALCl47BfGSjR9CA4Q871maq",
                                  "name": "Typography",
                                  "fileName": "material",
                                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                                  "importPath": "@mui/material",
                                  "expanded": false,
                                  "depth": 8,
                                  "thirdParty": true,
                                  "reactRouter": false,
                                  "reduxConnect": false,
                                  "count": 1,
                                  "props": {},
                                  "children": [],
                                  "parentList": [
                                    "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagList/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImgScrollerView/ImageCard/ImageCard.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                                  ],
                                  "error": ""
                                },
                                {
                                  "id": "HXxJGvzoAF5YE5LbXC4kS6VC2rOLaZwe",
                                  "name": "Tooltip",
                                  "fileName": "material",
                                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                                  "importPath": "@mui/material",
                                  "expanded": false,
                                  "depth": 8,
                                  "thirdParty": true,
                                  "reactRouter": false,
                                  "reduxConnect": false,
                                  "count": 1,
                                  "props": {
                                    "title": true,
                                    "placement": true
                                  },
                                  "children": [],
                                  "parentList": [
                                    "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagList/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImgScrollerView/ImageCard/ImageCard.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                                  ],
                                  "error": ""
                                }
                              ],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagList/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImgScrollerView/ImageCard/ImageCard.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagList/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImgScrollerView/ImageCard/ImageCard.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ImgScrollerView/ImageCard/ImageCard.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "Yi8LP54lvMkZfWyKQbpGzB1vHWZOV0aL",
              "name": "TagSidebar",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
              "importPath": "../TagSidebar",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "onCloseClicked": true,
                "tags": true,
                "onValueAssigned": true,
                "onValueRemoved": true,
                "onCreateNewTagAndValue": true
              },
              "children": [
                {
                  "id": "SEqB77HJl3GKKRXxYa9KxmslTMKNZhGj",
                  "name": "IconButton",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 2,
                  "props": {
                    "onClick": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "QW24JExZxkSPorxeNSplXCRNP7QZ3vRx",
                  "name": "ArrowBackIosIcon",
                  "fileName": "ArrowBackIos",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/ArrowBackIos",
                  "importPath": "@mui/icons-material/ArrowBackIos",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "9jDyz8zgXzYaZRVBTwufIf4W7otNfm7H",
                  "name": "ArrowForwardIosIcon",
                  "fileName": "ArrowForwardIos",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/ArrowForwardIos",
                  "importPath": "@mui/icons-material/ArrowForwardIos",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "h0erMQZOWEBFPXo6S0IZmjnIp6M1Xy9s",
                  "name": "CloseIcon",
                  "fileName": "Close",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/Close",
                  "importPath": "@mui/icons-material/Close",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "v45QaUy0OpTbjL2we1OuO2bHQGAxlT3u",
                  "name": "Typography",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 2,
                  "props": {
                    "variant": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "apPyblMrL6JVdguG9YMRfD4eMyLcAS91",
                  "name": "MultiValuesChip",
                  "fileName": "MultiValuesChip.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                  "importPath": "components/MultiValuesChip/MultiValuesChip",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "key": true,
                    "name": true,
                    "values": true,
                    "chipColor": true,
                    "onChipRemove": true
                  },
                  "children": [
                    {
                      "id": "9O9CCVBHnExwZTneeojEPvGVbGEWhubX",
                      "name": "TypographyWithMaxLength",
                      "fileName": "index.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                      "importPath": "components/TypographyWithMaxLength",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "lineHeight": true,
                        "maxLength": true,
                        "text": true,
                        "variant": true
                      },
                      "children": [
                        {
                          "id": "AiSwNIl9gCirm5DCIEdAIlZiPq4YQy3J",
                          "name": "Typography",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {},
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "Z6gq1kuHOo6n4YAaNq6XeQS0La2RVmc2",
                          "name": "Tooltip",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "title": true,
                            "placement": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "5fq4dtBoF2JBbAuxgtq5itQ6SrwrrV1Z",
                  "name": "TagAndValuesColumns",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/TagAndValuesColumns/index.tsx",
                  "importPath": "./TagAndValuesColumns",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "tags": true,
                    "onCreateNewTagAndValue": true,
                    "onValueClick": true
                  },
                  "children": [
                    {
                      "id": "krjdkcgeK2ZNNGddNAfOmDwYkAYAhiUs",
                      "name": "SearchBar",
                      "fileName": "index.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/SearchBar/index.tsx",
                      "importPath": "components/SearchBar",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "value": true,
                        "invalidMessage": true,
                        "onSearchChange": true,
                        "buttonMessage": true,
                        "onButtonClick": true,
                        "placeholder": true,
                        "data-cy": true
                      },
                      "children": [
                        {
                          "id": "WPfFeVS9ufsWHoeM77x0nQbxB2nPhPCJ",
                          "name": "TextField",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "ref": true,
                            "onKeyDown": true,
                            "error": true,
                            "label": true,
                            "InputProps": true,
                            "position": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/SearchBar/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/TagAndValuesColumns/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "qk9ZLCIPDvbsjxFfhdMi03BkSHX2uoyA",
                          "name": "InputAdornment",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "position": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/SearchBar/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/TagAndValuesColumns/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "fgrVLhMa9ivTCQt5sMjXmOuQdEfOJYOo",
                          "name": "SearchIcon",
                          "fileName": "Search",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/Search",
                          "importPath": "@mui/icons-material/Search",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {},
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/SearchBar/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/TagAndValuesColumns/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/TagAndValuesColumns/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "J9NkYyX8XVzjbdKA6UhN4QxtvCEEl7LI",
                      "name": "ColoredChip",
                      "fileName": "index.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/ColoredChip/index.tsx",
                      "importPath": "components/ColoredChip",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 2,
                      "props": {
                        "label": true,
                        "onClick": true,
                        "variant": true,
                        "style": true,
                        "endIcon": true,
                        "fontSize": true,
                        "key": true,
                        "maxLength": true
                      },
                      "children": [
                        {
                          "id": "tK3gKd3XYhBgkjtW6RpXJBU0iCq3edqH",
                          "name": "TypographyWithMaxLength",
                          "fileName": "index.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                          "importPath": "../TypographyWithMaxLength",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "text": true,
                            "maxLength": true
                          },
                          "children": [
                            {
                              "id": "2NSnvb4YOKbN9fW9vscHfAvcsj6vGvNr",
                              "name": "Typography",
                              "fileName": "material",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                              "importPath": "@mui/material",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {},
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/ColoredChip/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/TagAndValuesColumns/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "0JPH2UEOIdGiOw9d6cPYA43usL4Io3em",
                              "name": "Tooltip",
                              "fileName": "material",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                              "importPath": "@mui/material",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "title": true,
                                "placement": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/ColoredChip/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/TagAndValuesColumns/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ColoredChip/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/TagAndValuesColumns/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/TagAndValuesColumns/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "lOWQ4wuIWfmXFnW3DMS1bws82Dpt3kYa",
                      "name": "ArrowForwardIos",
                      "fileName": "icons-material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material",
                      "importPath": "@mui/icons-material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "fontSize": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/TagAndValuesColumns/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagSidebar/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "PRRzQNHorhvj01It70IyWEF9keScihLt",
              "name": "HideUnlessFeatureEnabled",
              "fileName": "HideUnlessFeatureEnabled.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HideUnlessFeatureEnabled/HideUnlessFeatureEnabled.tsx",
              "importPath": "components/HideUnlessFeatureEnabled/HideUnlessFeatureEnabled",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "flag": true
              },
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "bfjKA7hb9hYwc9RF3hRjoS6tau5qnI8Y",
              "name": "RelabellingImagesView",
              "fileName": "ImagesViewRelabelling",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageViewRelabelling/ImagesViewRelabelling",
              "importPath": "features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageViewRelabelling/ImagesViewRelabelling",
              "expanded": false,
              "depth": 3,
              "thirdParty": true,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "imageKey": true,
                "metaInfo": true,
                "imageKeySequence": true,
                "refetchImageIds": true,
                "handleClose": true
              },
              "children": [],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewImageGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            }
          ],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "dCnEVjscYORTHwlM7r1JO2PJXBjTyLjI",
          "name": "OverviewBoundingBoxGroups",
          "fileName": "index.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
          "importPath": "./OverviewBoundingBoxGroups",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {
            "filters": true,
            "groupBy": true,
            "boundingBoxSets": true,
            "fetchNextPageForSet": true,
            "toggleFilters": true
          },
          "children": [
            {
              "id": "iGg2fqYuOnMDpuImIGEZdOKeMMCiNTaP",
              "name": "CustomDraggable",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
              "importPath": "features/DatasetExplorer/ChartCustomDraggable",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "getImageIdFromEmbeddingView": true,
                "filters": true,
                "groupBy": true,
                "toggleFilters": true
              },
              "children": [
                {
                  "id": "wr4gOcmEeZH3e2dqciwRDPOxIwouIPUg",
                  "name": "Button",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "data-cy": true,
                    "onClick": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "YKUEUUhdGdrBewzh2rQWOYPPNu19dyHA",
                  "name": "ResizableWindow",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                  "importPath": "components/ResizableWindow",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "title": true,
                    "fullView": true,
                    "onFullView": true,
                    "onMinimize": true,
                    "onClose": true,
                    "onResize": true
                  },
                  "children": [
                    {
                      "id": "LWckspELrJefSqfYc2kYykk1DLfbaJ8p",
                      "name": "Draggable",
                      "fileName": "react-draggable",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/react-draggable",
                      "importPath": "react-draggable",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "handle": true,
                        "ref": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "UyZ7t14MWWY2rVvhTwj0ZdO6Byej23ix",
                      "name": "Stack",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 2,
                      "props": {
                        "id": true,
                        "direction": true,
                        "justifyContent": true,
                        "alignItems": true,
                        "p": true,
                        "gap": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "KoWSbTfd9Litxgz9XHFD6YU46QcLsYys",
                      "name": "Typography",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "paddingX": true,
                        "variant": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "mtRnBgAW1yYbyBVYRmT4Rphsi6mqpizr",
                      "name": "Button",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "7oerx0z7mSa1sPvJB24wNLiNfOzcUmSa",
                      "name": "CloseFullscreenIcon",
                      "fileName": "CloseFullscreen",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/CloseFullscreen",
                      "importPath": "@mui/icons-material/CloseFullscreen",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "onClick": true,
                        "sx": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "xv516nOekP9UoyCOcraiwzH5zyrrgGqn",
                      "name": "OpenInFullIcon",
                      "fileName": "OpenInFull",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/OpenInFull",
                      "importPath": "@mui/icons-material/OpenInFull",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "onClick": true,
                        "sx": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "xKi2GVpJcYHZD1aSZoaXHSVxTrShl23p",
                      "name": "CloseIcon",
                      "fileName": "Close",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/Close",
                      "importPath": "@mui/icons-material/Close",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "onClick": true,
                        "sx": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/ResizableWindow/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "L9TYsdq3FvVclONAHcL13MqBgM4LvIex",
                  "name": "Stepper",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/Stepper/index.tsx",
                  "importPath": "components/Stepper",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "onStepChange": true
                  },
                  "children": [
                    {
                      "id": "dHHrRYdkj5YQjI7YntoyNqvsu7AmQP1G",
                      "name": "MobileStepper",
                      "fileName": "MobileStepper",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/MobileStepper",
                      "importPath": "@mui/material/MobileStepper",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "steps": true,
                        "position": true,
                        "variant": true,
                        "activeStep": true,
                        "sx": true,
                        "nextButton": true,
                        "size": true,
                        "onClick": true,
                        "disabled": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/Stepper/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "Hl4aGYztka0ct4FQQKa1CttwBQN3Sj7h",
                      "name": "Button",
                      "fileName": "Button",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Button",
                      "importPath": "@mui/material/Button",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 2,
                      "props": {
                        "size": true,
                        "onClick": true,
                        "disabled": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/Stepper/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "cB5Jv62zQ87y63gHq3vov9oXdQr5s739",
                      "name": "KeyboardArrowRight",
                      "fileName": "KeyboardArrowRight",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/KeyboardArrowRight",
                      "importPath": "@mui/icons-material/KeyboardArrowRight",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/Stepper/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "3lJHW8nie5mEYmlymbjgGXwpHGieeZk6",
                      "name": "KeyboardArrowLeft",
                      "fileName": "KeyboardArrowLeft",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/KeyboardArrowLeft",
                      "importPath": "@mui/icons-material/KeyboardArrowLeft",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/Stepper/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "LbncdH8fwWqchDI7vBLnEKMZs4pGIGWF",
                  "name": "ConfusionMatrix",
                  "fileName": "ConfusionMatrix.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/ConfusionMatrix.tsx",
                  "importPath": "components/HighCharts/ConfusionMatrix",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "ref": true,
                    "data": true,
                    "xAxisCategories": true,
                    "yAxisCategories": true,
                    "xAxisFilters": true,
                    "yAxisFilters": true,
                    "title": true,
                    "onPointClicked": true
                  },
                  "children": [
                    {
                      "id": "4RKXgZteT4yD0waqwOKOC7MXP6TnsUKd",
                      "name": "HighchartsReact",
                      "fileName": "highcharts-react-official",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/highcharts-react-official",
                      "importPath": "highcharts-react-official",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "ref": true,
                        "highcharts": true,
                        "containerProps": true,
                        "options": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/ConfusionMatrix.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "K89HFPMmxtNJSbciRUEIbpfXkR4VlX3t",
                  "name": "CircularProgress",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "O1dbxY5gMDKeYbA5NrfUXLCySEXuaU8b",
                  "name": "EmbeddingView",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                  "importPath": "components/HighCharts/EmbeddingViewer",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "ref": true,
                    "datasetName": true,
                    "viewerData": true,
                    "embeddingType": true,
                    "onEmbeddingTypeChange": true,
                    "getImageIdFromEmbeddingView": true,
                    "embeddingSource": true,
                    "onEmbeddingSourceChange": true,
                    "colorByOptions": true,
                    "colorBy": true,
                    "onColorByChange": true,
                    "loading": true
                  },
                  "children": [
                    {
                      "id": "KFBbREtJMMUCXnuqcE4XEj6jt2GpqAmz",
                      "name": "Box",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 6,
                      "props": {
                        "display": true,
                        "flexDirection": true,
                        "alignItems": true,
                        "gap": true,
                        "justifyContent": true,
                        "height": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "uR9YJ9dDYgS3RsVYDjpXpfZgv2yVi0Nr",
                      "name": "ItemGroup",
                      "fileName": "index.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/ItemGroup/index.tsx",
                      "importPath": "components/ItemGroup",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 2,
                      "props": {
                        "title": true
                      },
                      "children": [
                        {
                          "id": "ecy463Ww1yqGjOPQlGMUNCY6n7d1Zsk5",
                          "name": "Box",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "position": true,
                            "color": true,
                            "top": true,
                            "left": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ItemGroup/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "gnemcmO7IdUAAYpMyNIYHIiwLqdxCoCD",
                          "name": "Typography",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "variant": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ItemGroup/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "eIu5xbmiwYIgRPypMEpgfuH3bXIl1IlF",
                          "name": "React",
                          "fileName": "react",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/react",
                          "importPath": "react",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "key": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ItemGroup/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "h1P6f7lCCJYUPvTkfbx4z3jL56nU96Aq",
                          "name": "Divider",
                          "fileName": "material",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                          "importPath": "@mui/material",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "variant": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/ItemGroup/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "lgaT8tQN3MhihJObDQeP0kBP8dQZ1L2D",
                      "name": "Typography",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 6,
                      "props": {},
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "blKytuFTUG6BvHGfgMTvOXo540Y3YwTo",
                      "name": "ToggleButtonGroup",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 4,
                      "props": {
                        "color": true,
                        "value": true,
                        "onChange": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "nKAxql0r4dAUKx7QmwfzG5QOm3TfNEyH",
                      "name": "ToggleButton",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 7,
                      "props": {
                        "key": true,
                        "value": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "oPA4G64fZVztVsrLN3mAd7VSvnJymPie",
                      "name": "Dropdown",
                      "fileName": "index.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                      "importPath": "components/Dropdown",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 2,
                      "props": {
                        "text": true,
                        "options": true,
                        "selected": true,
                        "onFilterClick": true
                      },
                      "children": [
                        {
                          "id": "jSDtnGt7tCmpL2sqHAilm9gFDBVxGuz5",
                          "name": "DropdownButton",
                          "fileName": "index.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/DropdownButton/index.tsx",
                          "importPath": "components/DropdownButton",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "onClick": true,
                            "open": true
                          },
                          "children": [
                            {
                              "id": "hR3T6uthP90iz5CFtYscA4b2Gwb2qFot",
                              "name": "KeyboardArrowDownIcon",
                              "fileName": "KeyboardArrowDown",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/KeyboardArrowDown",
                              "importPath": "@mui/icons-material/KeyboardArrowDown",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {},
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/DropdownButton/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "X6U30UcZOZMZyi0jo6iP7hhtHuk6MXWK",
                          "name": "DropDown",
                          "fileName": "index.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                          "importPath": "components/DropdownMenu",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "items": true,
                            "handleClose": true,
                            "anchorEl": true
                          },
                          "children": [
                            {
                              "id": "sRvfPHy4NJKCNDgoSScPfri8FKGA1ET7",
                              "name": "Menu",
                              "fileName": "Menu",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Menu",
                              "importPath": "@mui/material/Menu",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "id": true,
                                "anchorEl": true,
                                "open": true,
                                "onClose": true,
                                "anchorOrigin": true,
                                "sx": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "ArADwtpwEVNK7uyvXYN4vqkZeH2Khmnj",
                              "name": "MenuItem",
                              "fileName": "MenuItem",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/MenuItem",
                              "importPath": "@mui/material/MenuItem",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "data-cy": true,
                                "data-id": true,
                                "key": true,
                                "style": true,
                                "onClick": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "oYP2ZKYMuUcFxMOKFzCbKHSFGkJ3s3dc",
                              "name": "Checkbox",
                              "fileName": "Checkbox",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material/Checkbox",
                              "importPath": "@mui/material/Checkbox",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "checked": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/components/DropdownMenu/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/Dropdown/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "zRa3jogJlcW7chPknXS2q7dKd0T26Xl4",
                      "name": "LoadingBarWithMessage",
                      "fileName": "LoadingBar",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/LoadingBar",
                      "importPath": "components/HighCharts/EmbeddingViewer/LoadingBar",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "message": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    },
                    {
                      "id": "0UdHowuOJ2OYp7j5ka0gVqRnPJTSHS4g",
                      "name": "ScatterPlot",
                      "fileName": "ScatterPlot.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/ScatterPlot.tsx",
                      "importPath": "components/HighCharts/ScatterPlot",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "ref": true,
                        "datasetName": true,
                        "title": true,
                        "xAxisTitle": true,
                        "yAxisTitle": true,
                        "data": true,
                        "isLegendVisible": true,
                        "isImageAsPoint": true,
                        "getImageIdFromEmbeddingView": true
                      },
                      "children": [
                        {
                          "id": "wfTt1UiFEqUWiSMsrXG0XUOGX2l3WjF3",
                          "name": "HighchartsReact",
                          "fileName": "highcharts-react-official",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/highcharts-react-official",
                          "importPath": "highcharts-react-official",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "ref": true,
                            "highcharts": true,
                            "options": true,
                            "containerProps": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/ScatterPlot.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/EmbeddingViewer/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ChartCustomDraggable/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "0e9K6m2DL2zaGeM9rt9hjZSxulgAeuJZ",
              "name": "ImageList",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/ImageList/index.tsx",
              "importPath": "components/ImageList",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "id": true,
                "dataLength": true,
                "fetchNextPage": true,
                "hasMore": true
              },
              "children": [
                {
                  "id": "a8WkGElmuDsR2BiFwcUmRcQ28PiGzlPK",
                  "name": "InfiniteScroll",
                  "fileName": "react-infinite-scroll-component",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/react-infinite-scroll-component",
                  "importPath": "react-infinite-scroll-component",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "dataLength": true,
                    "next": true,
                    "scrollThreshold": true,
                    "scrollableTarget": true,
                    "hasMore": true,
                    "loader": true,
                    "style": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/ImageList/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "taZtwkWHr15alIY8uQLWoL9omI6ng6c9",
                  "name": "CircularProgress",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/ImageList/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "vE8Ozr9HAWOcd05sjR2LB7s2Eh9KpTlG",
              "name": "ImageBoundingBoxPairs",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/ImageBoundingBoxPairsCard/index.tsx",
              "importPath": "components/ImageBoundingBoxPairsCard",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "key": true,
                "match_properties": true,
                "annotation": true,
                "prediction": true,
                "showAnnotation": true,
                "showPrediction": true,
                "onClick": true
              },
              "children": [
                {
                  "id": "hKhodVuNL8j9uFQ8rFmeJB73zAsH0Gvu",
                  "name": "BoundingBoxContainer",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/BoundingBoxContainer/index.tsx",
                  "importPath": "components/BoundingBoxContainer",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/ImageBoundingBoxPairsCard/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "oLXQKTkbliPDmwfrZjBkEUde4kS3avfI",
                  "name": "BoundingBox",
                  "fileName": "index.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/BoundingBox/index.tsx",
                  "importPath": "components/BoundingBox",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 2,
                  "props": {
                    "coordinates": true,
                    "fill": true,
                    "variant": true,
                    "categoryPosition": true
                  },
                  "children": [
                    {
                      "id": "VvgpKMZUPUtUTkqRG8h3jcwaA7NGzLaM",
                      "name": "Typography",
                      "fileName": "material",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                      "importPath": "@mui/material",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": true,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "color": true,
                        "fontSize": true,
                        "whiteSpace": true
                      },
                      "children": [],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/components/BoundingBox/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/components/ImageBoundingBoxPairsCard/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/ImageBoundingBoxPairsCard/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "GWnHqxhFQV2JVRZRUM7vs0R3eGjCvETi",
                  "name": "Typography",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/ImageBoundingBoxPairsCard/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "Et8JNQuGoEmkSRZseELoWzs0MVFgzzcg",
              "name": "Accordion",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
              "importPath": "components/Accordion",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "key": true,
                "title": true,
                "startExpanded": true
              },
              "children": [
                {
                  "id": "H7dllFjkwmipfL369QznXIzETewmAXjI",
                  "name": "Accordion",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "id": true,
                    "data-cy": true,
                    "sx": true,
                    "expanded": true,
                    "ref": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "cXqF3FpnAhyuTiHNYUjbTs0CzKQ6U8bP",
                  "name": "AccordionSummary",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "onClick": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "FPPbmLPEdWmwWlZReavnoJi6xVc4SpS8",
                  "name": "Box",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 3,
                  "props": {
                    "display": true,
                    "justifyContent": true,
                    "width": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "2LsYsNpeOaznniky9UFmyfpPgLmdVaJU",
                  "name": "Typography",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 2,
                  "props": {
                    "mr": true,
                    "color": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "GJUsYsI61PTa2F638JNXdGKZJ8XqytsX",
                  "name": "ArrowUpwardIcon",
                  "fileName": "ArrowUpward",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/ArrowUpward",
                  "importPath": "@mui/icons-material/ArrowUpward",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "J3yW0Bl161erTuKpUciv4cBwU331U8aV",
                  "name": "ArrowDownwardIcon",
                  "fileName": "ArrowDownward",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/ArrowDownward",
                  "importPath": "@mui/icons-material/ArrowDownward",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {},
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "u0WyFqyS5U4kyorDCRVv078hX3Xkc3vX",
                  "name": "AccordionDetails",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "sx": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/Accordion/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/OverviewBoundingBoxGroups/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            }
          ],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "k4690n7uTELTXGRny6fCHDWwRrAu7v8T",
          "name": "FullScreenImage",
          "fileName": "index.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
          "importPath": "features/DatasetExplorer/FullScreenImage",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {
            "filters": true,
            "filterType": true
          },
          "children": [
            {
              "id": "ppPyAaPYJScUnN7AbI5RGRubzm3mR2YY",
              "name": "FullScreenDialog",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/FullScreenDialog/index.tsx",
              "importPath": "components/FullScreenDialog",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "isOpen": true,
                "handleClose": true
              },
              "children": [
                {
                  "id": "ArVegiQqrMffaAtTQGzyd6KXETMSP1WH",
                  "name": "Slide",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "direction": true,
                    "ref": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/FullScreenDialog/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "DYBQIDkO6j8XTrjl2D8z8PZW8QwsByhn",
                  "name": "DialogTitle",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "minHeight": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/FullScreenDialog/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "mXtFis1Rkr9EqwoPUlYh8jdRxnhYOLOB",
                  "name": "IconButton",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "edge": true,
                    "color": true,
                    "onClick": true,
                    "aria-label": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/FullScreenDialog/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "LhJ1yLG4JKfOeY9Vac7dimcZFCrK3w0x",
                  "name": "CloseIcon",
                  "fileName": "Close",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material/Close",
                  "importPath": "@mui/icons-material/Close",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "fontSize": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/FullScreenDialog/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            },
            {
              "id": "UyWvqh2DobREpZVgv1vl4WenUqWvBctP",
              "name": "ExpandedImageView",
              "fileName": "ExpandedImageView.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
              "importPath": "features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "imageKey": true,
                "metaInfo": true,
                "imageKeySequence": true,
                "filters": true,
                "setTitle": true,
                "onImageChange": true
              },
              "children": [
                {
                  "id": "IlW445xoh1GbsafZ2DURE5CXSt1TQZQs",
                  "name": "ExpandedImageViewContainer",
                  "fileName": "ExpandedImageViewContainer.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/container/ExpandedImageViewContainer.tsx",
                  "importPath": "container/ExpandedImageViewContainer",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "datasetName": true,
                    "modelKey": true,
                    "imageKey": true,
                    "computeMatching": true,
                    "filters": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "vRCWQ481a5x8ixExCjei1CtXCicOv9fW",
                  "name": "ExpandedImageViewObjectDetection",
                  "fileName": "ExpandedImgViewObjectDetection",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageViewObjectDetection/ExpandedImgViewObjectDetection",
                  "importPath": "../ExpandedImageViewObjectDetection/ExpandedImgViewObjectDetection",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "expandedImageViewMeta": true,
                    "onNext": true,
                    "onPrevious": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "VQB0bHZlBaqCqHRawY83DKmNObtfJMWu",
                  "name": "ExpandedImgViewClassification",
                  "fileName": "ExpandedImgViewClassification.tsx",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                  "importPath": "features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": false,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "expandedImageViewMeta": true,
                    "handleNext": true,
                    "handlePrevious": true,
                    "heatmapFlag": true,
                    "changeHeatmapFlag": true
                  },
                  "children": [
                    {
                      "id": "buTQxuVHtnoS2IaG1KKbkuHkk7tOQfTt",
                      "name": "ExpandedImgCardClassification",
                      "fileName": "ExpandedImgCardClassification.tsx",
                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                      "importPath": "features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification",
                      "expanded": false,
                      "depth": 5,
                      "thirdParty": false,
                      "reactRouter": false,
                      "reduxConnect": false,
                      "count": 1,
                      "props": {
                        "expandedImageViewMeta": true,
                        "handleNext": true,
                        "handlePrevious": true,
                        "heatmapFlag": true,
                        "changeHeatmapFlag": true
                      },
                      "children": [
                        {
                          "id": "YUQ5IjGwK1OJEoqWf1rSgEFkykN1ST9Q",
                          "name": "ExpandedImageViewerLayout",
                          "fileName": "index.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ExpandedImageViewerLayout/index.tsx",
                          "importPath": "features/DatasetExplorer/ExpandedImageViewerLayout",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "expandedImageViewMeta": true,
                            "onNext": true,
                            "onPrevious": true,
                            "imageContent": true,
                            "alwaysShowLabels": true,
                            "drawBoxes": true,
                            "imagePath": true,
                            "imageSize": true
                          },
                          "children": [
                            {
                              "id": "GJD8xeJpSHKM2pTFfPeyuDCKB6rsvoVy",
                              "name": "Button",
                              "fileName": "material",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                              "importPath": "@mui/material",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 2,
                              "props": {
                                "size": true,
                                "onClick": true,
                                "disabled": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ExpandedImageViewerLayout/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "7z5EIk6mTqIkxydimc1PXTQpvIXflXX0",
                              "name": "KeyboardArrowRight",
                              "fileName": "icons-material",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material",
                              "importPath": "@mui/icons-material",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {},
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ExpandedImageViewerLayout/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "j5woAptrNwV7EJtjyJ5IzRIAoiM6N7Uo",
                              "name": "KeyboardArrowLeft",
                              "fileName": "icons-material",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/icons-material",
                              "importPath": "@mui/icons-material",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {},
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ExpandedImageViewerLayout/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "8YCrx6TtLcy1Xb8y0N71MEBzhtAw5MQH",
                          "name": "ImageWithBox",
                          "fileName": "ImageWithBox.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ImageWithBox/ImageWithBox.tsx",
                          "importPath": "../../ImageWithBox/ImageWithBox",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "alwaysShowLabels": true,
                            "drawBoxes": true,
                            "imagePath": true,
                            "imageSize": true
                          },
                          "children": [
                            {
                              "id": "1qhtrVH0bOKnXj4qh9vO2kczphjgFZ6O",
                              "name": "BoundingBoxSvgComponent",
                              "fileName": "index.tsx",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/BoundingBoxCanvas/BoundingBoxSvgComponent/index.tsx",
                              "importPath": "features/DatasetExplorer/BoundingBoxCanvas/BoundingBoxSvgComponent",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": false,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "key": true,
                                "x": true,
                                "y": true,
                                "width": true,
                                "height": true,
                                "color": true,
                                "strokeWidth": true,
                                "strokeDash": true,
                                "onClick": true,
                                "text": true,
                                "confidenceScore": true,
                                "showAlways": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ImageWithBox/ImageWithBox.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "hQ6fuFufOElxfMXM3z7g4FoSDgnNdOz5",
                          "name": "TabsContainer",
                          "fileName": "index.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TabsContainer/index.tsx",
                          "importPath": "features/DatasetExplorer/TabsContainer",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "tabs": true,
                            "tags": true,
                            "heatmapFlag": true,
                            "changeHeatmapFlag": true
                          },
                          "children": [
                            {
                              "id": "Sk0fWtlRxANNzazYawt6VNefghZOWe4D",
                              "name": "Tabs",
                              "fileName": "material",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                              "importPath": "@mui/material",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "value": true,
                                "onChange": true,
                                "aria-label": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TabsContainer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "bodYFzryLr58i6U0mlAFLYnR09HEYtQz",
                              "name": "TabPanel",
                              "fileName": "index.tsx",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TabsContainer/TabPanel/index.tsx",
                              "importPath": "./TabPanel",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": false,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "key": true,
                                "value": true,
                                "index": true
                              },
                              "children": [
                                {
                                  "id": "oiiIu9EOpNhmaGeebCnq19pDtaFviUXp",
                                  "name": "Box",
                                  "fileName": "material",
                                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                                  "importPath": "@mui/material",
                                  "expanded": false,
                                  "depth": 8,
                                  "thirdParty": true,
                                  "reactRouter": false,
                                  "reduxConnect": false,
                                  "count": 1,
                                  "props": {
                                    "sx": true
                                  },
                                  "children": [],
                                  "parentList": [
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TabsContainer/TabPanel/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TabsContainer/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                                  ],
                                  "error": ""
                                }
                              ],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TabsContainer/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "J2xiVpjs39y0X9euBgkAS2MnuQVNzBR9",
                          "name": "ExpandedImageDetailsComponentClassification",
                          "fileName": "ExpandedImageDetailsComponentClassification.tsx",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification.tsx",
                          "importPath": "../../ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": false,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "tags": true,
                            "heatmapFlag": true,
                            "changeHeatmapFlag": true
                          },
                          "children": [
                            {
                              "id": "qoYl4DsfMIwLq4ad9HxUxcZ8KhaXRHwe",
                              "name": "Container",
                              "fileName": "utilities",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/utilities",
                              "importPath": "./utilities",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {},
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "ZCCS2tLw4FPhuA6DROZ6sYQThu2Wi0Iq",
                              "name": "DetailsContainer",
                              "fileName": "utilities",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/utilities",
                              "importPath": "./utilities",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {},
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "KQQXiFoLcFYweBdLdfWX6d8jFypTVd73",
                              "name": "TitleText",
                              "fileName": "utilities",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/utilities",
                              "importPath": "./utilities",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 2,
                              "props": {
                                "variant": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "kZdZg5KfMZfIkIgzqeBRhDXonoIeLiko",
                              "name": "ToggleSwitch",
                              "fileName": "SwitchButton",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/SwitchButton/SwitchButton",
                              "importPath": "components/SwitchButton/SwitchButton",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "text": true,
                                "checked": true,
                                "onChange": true
                              },
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "3BzFBVTNamhTwsJR5EDhJQ9hHj2w8Uum",
                              "name": "TagsContainer",
                              "fileName": "utilities",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/utilities",
                              "importPath": "./utilities",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": true,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {},
                              "children": [],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            },
                            {
                              "id": "fnE6pVdE67hc1EU8fsZ0I6BwtZWmP9Ov",
                              "name": "TagList",
                              "fileName": "index.tsx",
                              "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagList/index.tsx",
                              "importPath": "features/DatasetExplorer/TagList",
                              "expanded": false,
                              "depth": 7,
                              "thirdParty": false,
                              "reactRouter": false,
                              "reduxConnect": false,
                              "count": 1,
                              "props": {
                                "tags": true
                              },
                              "children": [
                                {
                                  "id": "M23mtydq9CTyRJnW1OzVCN6iok1ZzSn0",
                                  "name": "MultiValuesChip",
                                  "fileName": "MultiValuesChip.tsx",
                                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                                  "importPath": "components/MultiValuesChip/MultiValuesChip",
                                  "expanded": false,
                                  "depth": 8,
                                  "thirdParty": false,
                                  "reactRouter": false,
                                  "reduxConnect": false,
                                  "count": 1,
                                  "props": {
                                    "nameLength": true,
                                    "valuesLength": true,
                                    "small": true,
                                    "key": true,
                                    "name": true,
                                    "values": true,
                                    "onChipRemove": true,
                                    "chipColor": true
                                  },
                                  "children": [
                                    {
                                      "id": "cee1IINsS0z3625Ft4BaSDXEEl0Qgger",
                                      "name": "TypographyWithMaxLength",
                                      "fileName": "index.tsx",
                                      "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                                      "importPath": "components/TypographyWithMaxLength",
                                      "expanded": false,
                                      "depth": 9,
                                      "thirdParty": false,
                                      "reactRouter": false,
                                      "reduxConnect": false,
                                      "count": 1,
                                      "props": {
                                        "lineHeight": true,
                                        "maxLength": true,
                                        "text": true,
                                        "variant": true
                                      },
                                      "children": [
                                        {
                                          "id": "CdUVP7p85ZOUv1TtwY4oB3McHohVk3ti",
                                          "name": "Typography",
                                          "fileName": "material",
                                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                                          "importPath": "@mui/material",
                                          "expanded": false,
                                          "depth": 10,
                                          "thirdParty": true,
                                          "reactRouter": false,
                                          "reduxConnect": false,
                                          "count": 1,
                                          "props": {},
                                          "children": [],
                                          "parentList": [
                                            "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagList/index.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                                          ],
                                          "error": ""
                                        },
                                        {
                                          "id": "hUahXDdtFAjUfCcpzxxoFEvQAv8iLFXC",
                                          "name": "Tooltip",
                                          "fileName": "material",
                                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                                          "importPath": "@mui/material",
                                          "expanded": false,
                                          "depth": 10,
                                          "thirdParty": true,
                                          "reactRouter": false,
                                          "reduxConnect": false,
                                          "count": 1,
                                          "props": {
                                            "title": true,
                                            "placement": true
                                          },
                                          "children": [],
                                          "parentList": [
                                            "/Users/aue/Documents/dashboard/frontend/src/components/TypographyWithMaxLength/index.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagList/index.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                                          ],
                                          "error": ""
                                        }
                                      ],
                                      "parentList": [
                                        "/Users/aue/Documents/dashboard/frontend/src/components/MultiValuesChip/MultiValuesChip.tsx",
                                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagList/index.tsx",
                                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification.tsx",
                                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                                      ],
                                      "error": ""
                                    }
                                  ],
                                  "parentList": [
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/TagList/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                                  ],
                                  "error": ""
                                }
                              ],
                              "parentList": [
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImageDetailsComponent/ExpandedImageDetailsComponentClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                              ],
                              "error": ""
                            }
                          ],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        },
                        {
                          "id": "L40ksBKa3u0ZurDdYmVPwWK9nfb5PO3d",
                          "name": "BarChart",
                          "fileName": "BarChart",
                          "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HighCharts/BarChart",
                          "importPath": "components/HighCharts/BarChart",
                          "expanded": false,
                          "depth": 6,
                          "thirdParty": true,
                          "reactRouter": false,
                          "reduxConnect": false,
                          "count": 1,
                          "props": {
                            "data": true,
                            "xAxisCategories": true,
                            "yAxisTitle": true,
                            "yAxisMin": true,
                            "yAxisMax": true,
                            "title": true
                          },
                          "children": [],
                          "parentList": [
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImgCardClassification/ExpandedImgCardClassification.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                          ],
                          "error": ""
                        }
                      ],
                      "parentList": [
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgViewClassification/ExpandedImgViewClassification.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                        "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                      ],
                      "error": ""
                    }
                  ],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/ImageView/ExpandedImgView/ExpandedImgView/ExpandedImageView.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/FullScreenImage/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            }
          ],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "oJ30d8dQofUm6lXjl286ZgZlaIhj1CW5",
          "name": "HideUnlessFeatureEnabled",
          "fileName": "HideUnlessFeatureEnabled.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/HideUnlessFeatureEnabled/HideUnlessFeatureEnabled.tsx",
          "importPath": "components/HideUnlessFeatureEnabled/HideUnlessFeatureEnabled",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {
            "flag": true
          },
          "children": [],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "TMwFOfKmnZtOTyWGSo0K4L0Vk4qRyS0t",
          "name": "BottomActionBarContainer",
          "fileName": "index.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/layouts/BottomActionBarContainer/index.tsx",
          "importPath": "layouts/BottomActionBarContainer",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {},
          "children": [],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        },
        {
          "id": "7FUbPDrtKx8ndla8pT7TpYrc0rJGhLX3",
          "name": "DataQualityCheckerButton",
          "fileName": "index.tsx",
          "filePath": "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DataQualityCheckerButton/index.tsx",
          "importPath": "features/DatasetExplorer/DataQualityCheckerButton",
          "expanded": false,
          "depth": 2,
          "thirdParty": false,
          "reactRouter": false,
          "reduxConnect": false,
          "count": 1,
          "props": {},
          "children": [
            {
              "id": "DB7iY4lz3L4CpzUGC4oa19kGdypNfama",
              "name": "MultilineActionButton",
              "fileName": "index.tsx",
              "filePath": "/Users/aue/Documents/dashboard/frontend/src/components/MultilineActionButton/index.tsx",
              "importPath": "components/MultilineActionButton",
              "expanded": false,
              "depth": 3,
              "thirdParty": false,
              "reactRouter": false,
              "reduxConnect": false,
              "count": 1,
              "props": {
                "title": true,
                "appearDisabled": true,
                "subtitle": true,
                "onClick": true
              },
              "children": [
                {
                  "id": "WRqFqgzwhQsYtHswJYOvjY8zm2ys2nKQ",
                  "name": "Box",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 1,
                  "props": {
                    "marginX": true,
                    "marginY": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/MultilineActionButton/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DataQualityCheckerButton/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                },
                {
                  "id": "1DFmfFzpAPtetCpT6AScq3bAqvqB5Huz",
                  "name": "Typography",
                  "fileName": "material",
                  "filePath": "/Users/aue/Documents/dashboard/frontend/src/@mui/material",
                  "importPath": "@mui/material",
                  "expanded": false,
                  "depth": 4,
                  "thirdParty": true,
                  "reactRouter": false,
                  "reduxConnect": false,
                  "count": 2,
                  "props": {
                    "fontWeight": true,
                    "variant": true
                  },
                  "children": [],
                  "parentList": [
                    "/Users/aue/Documents/dashboard/frontend/src/components/MultilineActionButton/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DataQualityCheckerButton/index.tsx",
                    "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                    "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
                  ],
                  "error": ""
                }
              ],
              "parentList": [
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DataQualityCheckerButton/index.tsx",
                "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
                "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
              ],
              "error": ""
            }
          ],
          "parentList": [
            "/Users/aue/Documents/dashboard/frontend/src/features/DatasetExplorer/DatasetExplorer.tsx",
            "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
          ],
          "error": ""
        }
      ],
      "parentList": [
        "../dashboard/frontend/src/pages/DatasetExplorerPage.tsx"
      ],
      "error": ""
    }
  ],
  "parentList": [],
  "props": {},
  "error": ""
}